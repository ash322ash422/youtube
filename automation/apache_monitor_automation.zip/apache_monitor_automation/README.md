# Apache Log Monitoring Automation (Teaching Project)

A small but "industry-shaped" automation pipeline that watches a (simulated)
Apache access log, detects problems, alerts administrators, and shows live
status on a Tkinter dashboard. Built to be read top-to-bottom as a teaching
example of a real monitoring automation.

## What it demonstrates

- **Producer/consumer processes** talking only through files (a log file and
  a status file) - no direct coupling, so each piece can be started, stopped,
  or restarted independently.
- **Tailing a growing file safely** (offset persistence, rotation handling).
- **Sliding-window health evaluation** instead of reacting to a single line.
- **Alert de-duplication / cooldown** so admins aren't spammed.
- **Pluggable notification channels** (console, file, e-mail) via a simple
  Strategy pattern.
- **Atomic status publishing** (`status.json`) so a reader never sees a
  half-written file.
- **A GUI that only displays state** - it never computes health itself.
- Graceful shutdown on Ctrl+C / SIGTERM, structured logging, and a config
  module that centralizes every tunable value.

## Project layout

```
apache_monitor_automation/
├── config.py              # all paths, thresholds, intervals, SMTP settings
├── log_generator.py       # simulates a live Apache server writing access.log
├── log_monitor.py         # THE AUTOMATION: tails log, detects issues, alerts, publishes status
├── gui_status.py          # Tkinter dashboard: green/red indicator buttons
├── utils/
│   └── notifier.py        # Console / File / Email alert channels + Notifier
├── scripts/
│   ├── simulate_crash.py  # manually inject a crash or error burst on demand
│   └── run_all.py         # convenience: launches generator + monitor + GUI together
├── logs/
│   ├── access.log             # the simulated apache access log (generated)
│   ├── generator_service.log  # log_generator.py's own operational log
│   └── monitor_service.log    # log_monitor.py's own operational log
├── alerts/
│   └── alerts.log          # persisted history of every alert ever sent
├── status/
│   └── status.json         # current health, written by the monitor, read by the GUI
└── state/
    └── monitor_offset.json # bookmark: how far the monitor has read the log
```

## Requirements

Python 3.9+. No third-party packages - everything (including `tkinter`) is
in the standard library. On some Linux distros you may need to install the
Tk bindings separately, e.g. `sudo apt-get install python3-tk`.

## Running it

Open three terminals in the project root (or just use the launcher, see
below).

**Terminal 1 - simulate the server:**
```bash
python log_generator.py
```
Writes fake access-log traffic to `logs/access.log`, with occasional error
bursts and full "crash" events sprinkled in at random.

**Terminal 2 - run the automation:**
```bash
python log_monitor.py
```
Every few seconds it reads whatever is new in `logs/access.log`, decides if
the server is healthy, writes `status/status.json`, and - if there's a
problem - alerts administrators (console + `alerts/alerts.log`, and e-mail
if you configure SMTP in `config.py`).

**Terminal 3 - watch the dashboard:**
```bash
python gui_status.py
```
A small window with two indicator buttons: **GREEN** (OK) and **RED**
(issue). It polls `status/status.json` every 2 seconds and lights up
accordingly, along with the reason and a timestamp.

**Or, all at once:**
```bash
python scripts/run_all.py
```

## Forcing a demo crash instantly

Rather than waiting for `log_generator.py` to randomly roll a crash, inject
one on demand:
```bash
python scripts/simulate_crash.py            # full crash burst -> CRITICAL -> RED
python scripts/simulate_crash.py --errors    # just a run of 5xx -> WARNING -> RED
```
Watch the monitor's terminal log the detection within a few seconds, and the
GUI flip to red.

## How detection works (log_monitor.py)

1. `LogTailer` remembers the byte offset it last read (`state/monitor_offset.json`)
   and only reads newly appended, *complete* lines each poll - like `tail -f`.
2. `HealthEvaluator` scans each new line for:
   - an HTTP status code >= 500 in the request line, or
   - an explicit crash marker (`AH00052 ... crashed ... CRASH`), simulating
     an Apache error-log entry.
   Matching events go into a sliding window (`config.MONITOR_WINDOW_SEC`).
3. Every poll, it evaluates the window:
   - `>= CRASH_THRESHOLD` crash markers -> **CRITICAL**
   - `>= ERROR_THRESHOLD` 5xx responses -> **WARNING**
   - no new log lines for `HEARTBEAT_TIMEOUT_SEC` -> **WARNING** (server may be down)
   - otherwise -> **OK**
4. `AlertManager` notifies admins immediately when status changes, and again
   every `ALERT_COOLDOWN_SEC` while it persists, plus a "recovered" message
   when it returns to OK.
5. `publish_status()` writes `status/status.json` atomically (write to a
   temp file, then rename) so `gui_status.py` never reads a partial file.

## Configuring e-mail alerts

By default, `config.SMTP_HOST` is empty, so alerts only go to the console
and `alerts/alerts.log` - handy for an offline classroom demo. To enable
real e-mail, fill in `SMTP_HOST`, `SMTP_USERNAME`, `SMTP_PASSWORD`,
`ALERT_FROM_ADDR`, and `ALERT_TO_ADDRS` in `config.py`.

## Ideas for extending this as a teaching exercise

- Add a `SlackChannel` or `WebhookChannel` to `utils/notifier.py`.
- Parse real Apache/Nginx logs instead of the generator's fake ones.
- Add a `scripts/simulate_crash.py --recover` flag that force-writes OK
  traffic to show the recovery notice firing.
- Swap `status.json` for a tiny HTTP endpoint and make the GUI poll that
  instead, to introduce networking.
- Containerize each of the three processes to teach multi-service Docker
  Compose setups.
