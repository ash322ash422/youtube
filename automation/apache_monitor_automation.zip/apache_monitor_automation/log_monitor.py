"""
log_monitor.py
===============
The core automation script. It:

  1. Periodically reads only the NEW bytes appended to the access log
     (like `tail -f`), remembering its position between polls (and even
     between restarts) so it never re-scans the whole file.
  2. Parses each new line for HTTP 5xx status codes and explicit crash
     markers, keeping a sliding time-window count of both.
  3. Evaluates overall server health: OK / WARNING / CRITICAL, and also
     flags a suspicious silence (no log activity) as a possible outage.
  4. Publishes a small JSON status file that other processes - such as the
     Tkinter GUI - can poll to show a live red/green indicator.
  5. Alerts administrators (console + file + optional e-mail) when a
     problem appears, with a cooldown so the same issue doesn't spam
     the inbox, and sends a "recovered" notice when health returns to OK.

Run:
    python log_monitor.py
Stop with Ctrl+C (or SIGTERM).
"""
from __future__ import annotations

import json
import logging
import re
import signal
import sys
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Deque, Optional, Tuple

import config
from utils.notifier import Alert, Notifier

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] monitor: %(message)s",
    handlers=[
        logging.FileHandler(config.MONITOR_APP_LOG, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("apache_monitor.monitor")

# Matches the status code in a combined/common log line, e.g.:  "GET / HTTP/1.1" 200 1234
# i.e. a closing quote, then the 3-digit HTTP status code, then the response size.
STATUS_LINE_RE = re.compile(r'"\s+(\d{3})\s+\S+')
CRASH_MARKER_RE = re.compile(r'crash', re.IGNORECASE)

STATUS_OK = "OK"
STATUS_WARNING = "WARNING"
STATUS_CRITICAL = "CRITICAL"


# ---------------------------------------------------------------------------
# Tailing
# ---------------------------------------------------------------------------
class LogTailer:
    """Reads only newly appended, complete lines of a growing log file.

    Tolerant of log rotation/truncation (if the file shrinks, we assume it
    was rotated and restart from byte 0). Persists its byte offset to disk
    so the service can be restarted without reprocessing the whole file -
    the same trick real log-shippers (Filebeat, Fluentd, etc.) use.
    """

    def __init__(self, path: Path, offset_file: Path):
        self.path = path
        self.offset_file = offset_file
        self._offset = self._load_offset()

    def _load_offset(self) -> int:
        if self.offset_file.exists():
            try:
                return json.loads(self.offset_file.read_text()).get("offset", 0)
            except (json.JSONDecodeError, OSError):
                return 0
        return 0

    def _save_offset(self) -> None:
        tmp = self.offset_file.with_suffix(".tmp")
        tmp.write_text(json.dumps({"offset": self._offset}))
        tmp.replace(self.offset_file)  # atomic replace

    def read_new_lines(self) -> list:
        if not self.path.exists():
            return []

        size = self.path.stat().st_size
        if size < self._offset:
            logger.warning("Log file appears truncated/rotated - resetting offset to 0.")
            self._offset = 0

        lines = []
        with self.path.open("r", encoding="utf-8", errors="replace") as fh:
            fh.seek(self._offset)
            while True:
                # readline() (unlike iterating the file object) keeps tell()
                # accurate, since Python's file iterator does internal
                # read-ahead buffering that breaks tell().
                raw_line = fh.readline()
                if not raw_line:
                    break
                if raw_line.endswith("\n"):
                    lines.append(raw_line.rstrip("\n"))
                    self._offset = fh.tell()
                else:
                    # incomplete line at EOF - wait for the writer to finish it
                    break
        self._save_offset()
        return lines


# ---------------------------------------------------------------------------
# Health evaluation
# ---------------------------------------------------------------------------
@dataclass
class Event:
    timestamp: float
    kind: str  # "error" | "crash"


class HealthEvaluator:
    """Keeps a sliding window of recent error/crash events and decides the
    overall server health status from them."""

    def __init__(self, window_sec: int, error_threshold: int, crash_threshold: int):
        self.window_sec = window_sec
        self.error_threshold = error_threshold
        self.crash_threshold = crash_threshold
        self._events: Deque[Event] = deque()

    def feed_line(self, line: str) -> None:
        now = time.time()
        if CRASH_MARKER_RE.search(line):
            self._events.append(Event(now, "crash"))
            return
        match = STATUS_LINE_RE.search(line)
        if match and int(match.group(1)) >= 500:
            self._events.append(Event(now, "error"))

    def _prune(self) -> None:
        cutoff = time.time() - self.window_sec
        while self._events and self._events[0].timestamp < cutoff:
            self._events.popleft()

    def evaluate(self) -> Tuple[str, str]:
        """Return (status, human-readable reason)."""
        self._prune()
        crash_count = sum(1 for e in self._events if e.kind == "crash")
        error_count = sum(1 for e in self._events if e.kind == "error")

        if crash_count >= self.crash_threshold:
            return STATUS_CRITICAL, (
                f"{crash_count} crash marker(s) detected in the last "
                f"{self.window_sec}s of the access log."
            )
        if error_count >= self.error_threshold:
            return STATUS_WARNING, (
                f"{error_count} HTTP 5xx responses in the last {self.window_sec}s "
                f"(threshold is {self.error_threshold})."
            )
        return STATUS_OK, "No issues detected."


# ---------------------------------------------------------------------------
# Status publishing (consumed by the Tkinter GUI)
# ---------------------------------------------------------------------------
def publish_status(status: str, reason: str) -> None:
    payload = {
        "status": status,
        "reason": reason,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    tmp = config.STATUS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(config.STATUS_FILE)  # atomic write so the GUI never reads a half-written file


# ---------------------------------------------------------------------------
# Alerting with cooldown + recovery notice
# ---------------------------------------------------------------------------
class AlertManager:
    """Decides WHEN to actually notify admins: immediately on a new/changed
    problem, then throttled by a cooldown while it persists, plus a single
    "recovered" notice when health returns to OK."""

    def __init__(self, notifier: Notifier, cooldown_sec: int):
        self.notifier = notifier
        self.cooldown_sec = cooldown_sec
        self._last_status: Optional[str] = None
        self._last_alert_time: float = 0.0

    def handle(self, status: str, reason: str) -> None:
        now = time.time()
        status_changed = status != self._last_status
        cooldown_elapsed = (now - self._last_alert_time) >= self.cooldown_sec

        if status in (STATUS_WARNING, STATUS_CRITICAL):
            if status_changed or cooldown_elapsed:
                self.notifier.notify(Alert(
                    severity=status,
                    title="Apache server issue detected" if status == STATUS_WARNING
                          else "Apache server CRASH detected",
                    message=reason,
                ))
                self._last_alert_time = now
        elif status == STATUS_OK and self._last_status in (STATUS_WARNING, STATUS_CRITICAL):
            self.notifier.notify(Alert(
                severity="INFO",
                title="Apache server recovered",
                message="Server health returned to normal.",
            ))

        self._last_status = status


# ---------------------------------------------------------------------------
# Main service loop
# ---------------------------------------------------------------------------
_running = True


def _handle_shutdown(signum, frame):  # noqa: ARG001
    global _running
    logger.info("Shutdown signal received, stopping monitor...")
    _running = False


def run() -> None:
    signal.signal(signal.SIGINT, _handle_shutdown)
    signal.signal(signal.SIGTERM, _handle_shutdown)

    tailer = LogTailer(config.ACCESS_LOG_FILE, config.MONITOR_OFFSET_FILE)
    evaluator = HealthEvaluator(config.MONITOR_WINDOW_SEC, config.ERROR_THRESHOLD, config.CRASH_THRESHOLD)
    alert_manager = AlertManager(Notifier(), config.ALERT_COOLDOWN_SEC)

    last_activity = time.time()
    logger.info("Monitor started. Watching %s every %ss.",
                config.ACCESS_LOG_FILE, config.MONITOR_POLL_INTERVAL_SEC)
    publish_status(STATUS_OK, "Monitor starting up...")

    while _running:
        new_lines = tailer.read_new_lines()
        if new_lines:
            last_activity = time.time()
            for line in new_lines:
                evaluator.feed_line(line)

        status, reason = evaluator.evaluate()

        # Heartbeat check: silence from a previously-active server is suspicious
        # (e.g. the process died and stopped logging entirely).
        idle_for = time.time() - last_activity
        if status == STATUS_OK and idle_for > config.HEARTBEAT_TIMEOUT_SEC:
            status = STATUS_WARNING
            reason = f"No new log activity for {int(idle_for)}s; server may be unresponsive."

        publish_status(status, reason)
        alert_manager.handle(status, reason)

        if status != STATUS_OK:
            logger.warning("Status=%s reason=%s", status, reason)
        else:
            logger.debug("Status=OK")

        time.sleep(config.MONITOR_POLL_INTERVAL_SEC)

    logger.info("Monitor stopped cleanly.")


if __name__ == "__main__":
    run()
