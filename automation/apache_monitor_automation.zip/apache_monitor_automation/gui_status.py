"""
gui_status.py
=============
Minimal Tkinter dashboard for the Apache monitoring automation.

Shows two indicator "lights" implemented as buttons:
    GREEN  -> everything OK
    RED    -> an issue / crash was detected

Design note for students: the GUI does NOT decide server health itself.
It simply polls status/status.json - written by log_monitor.py - every
couple of seconds and reflects whatever it finds. This is a common,
robust pattern for dashboards: the automation owns the decision, the UI
just subscribes to the published state. It also means you could open
several of these dashboards at once and they'd all agree.

Run:
    python gui_status.py
"""
from __future__ import annotations

import json
import tkinter as tk

import config

POLL_INTERVAL_MS = 2000

GREEN_ACTIVE = "#2ecc71"
GREEN_DIM = "#1e5631"
RED_ACTIVE = "#e74c3c"
RED_DIM = "#5c1a13"
BG = "#1c1c1c"
FG = "#eeeeee"


class StatusDashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Apache Server Monitor")
        self.geometry("380x280")
        self.configure(bg=BG)
        self.resizable(False, False)

        tk.Label(
            self, text="Server Health Dashboard", font=("Segoe UI", 14, "bold"),
            bg=BG, fg=FG,
        ).pack(pady=(16, 4))

        light_frame = tk.Frame(self, bg=BG)
        light_frame.pack(pady=10)

        # Two indicator buttons. They are intentionally disabled (not
        # clickable) - their job is purely to display state, driven by the
        # monitor's status.json, not to be pressed by the user.
        self.green_btn = tk.Button(
            light_frame, text="GREEN\nOK", width=12, height=4,
            font=("Segoe UI", 10, "bold"), relief="raised",
            state="disabled", disabledforeground="white",
        )
        self.green_btn.grid(row=0, column=0, padx=10)

        self.red_btn = tk.Button(
            light_frame, text="RED\nISSUE", width=12, height=4,
            font=("Segoe UI", 10, "bold"), relief="raised",
            state="disabled", disabledforeground="white",
        )
        self.red_btn.grid(row=0, column=1, padx=10)

        self.status_label = tk.Label(
            self, text="Status: unknown", font=("Segoe UI", 11, "bold"), bg=BG, fg=FG,
        )
        self.status_label.pack(pady=(14, 2))

        self.reason_label = tk.Label(
            self, text="", wraplength=340, justify="center",
            bg=BG, fg="#bbbbbb", font=("Segoe UI", 9),
        )
        self.reason_label.pack(pady=2)

        self.updated_label = tk.Label(self, text="", bg=BG, fg="#777777", font=("Segoe UI", 8))
        self.updated_label.pack(pady=(10, 0))

        hint = ("Tip: run log_generator.py to produce traffic and log_monitor.py "
                "to watch it. Use scripts/simulate_crash.py for an instant demo.")
        tk.Label(self, text=hint, wraplength=340, justify="center",
                 bg=BG, fg="#555555", font=("Segoe UI", 7)).pack(side="bottom", pady=8)

        self._poll()

    def _read_status(self) -> dict:
        try:
            with config.STATUS_FILE.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            return {
                "status": "UNKNOWN",
                "reason": "Waiting for log_monitor.py to publish a status...",
                "updated_at": "",
            }

    def _apply(self, data: dict) -> None:
        status = data.get("status", "UNKNOWN")
        reason = data.get("reason", "")
        updated_at = data.get("updated_at", "")

        if status == "OK":
            self.green_btn.configure(bg=GREEN_ACTIVE)
            self.red_btn.configure(bg=RED_DIM)
            self.status_label.configure(text="Status: OK", fg=GREEN_ACTIVE)
        elif status in ("WARNING", "CRITICAL"):
            self.green_btn.configure(bg=GREEN_DIM)
            self.red_btn.configure(bg=RED_ACTIVE)
            self.status_label.configure(text=f"Status: {status}", fg=RED_ACTIVE)
        else:
            self.green_btn.configure(bg=GREEN_DIM)
            self.red_btn.configure(bg=RED_DIM)
            self.status_label.configure(text="Status: UNKNOWN", fg="#999999")

        self.reason_label.configure(text=reason)
        if updated_at:
            self.updated_label.configure(text=f"Last update: {updated_at}")

    def _poll(self) -> None:
        data = self._read_status()
        self._apply(data)
        self.after(POLL_INTERVAL_MS, self._poll)


if __name__ == "__main__":
    app = StatusDashboard()
    app.mainloop()
