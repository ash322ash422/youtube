"""
config.py
=========
Central configuration for the Apache Log Monitoring Automation project.

Keeping every tunable value in one module (paths, thresholds, intervals,
credentials) is a standard industry practice: it lets you change behaviour
without touching business logic, and makes the system easy to reason about
during a demo or code review.
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# Directory layout
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent

LOG_DIR = BASE_DIR / "logs"        # apache-style logs + this project's own logs
ALERT_DIR = BASE_DIR / "alerts"    # persisted record of every alert ever sent
STATUS_DIR = BASE_DIR / "status"   # machine-readable status consumed by the GUI
STATE_DIR = BASE_DIR / "state"     # internal bookkeeping (tail offsets, etc.)

for _d in (LOG_DIR, ALERT_DIR, STATUS_DIR, STATE_DIR):
    _d.mkdir(parents=True, exist_ok=True)

ACCESS_LOG_FILE = LOG_DIR / "access.log"           # the fake apache log
STATUS_FILE = STATUS_DIR / "status.json"            # current health, read by GUI
ALERT_LOG_FILE = ALERT_DIR / "alerts.log"            # human-readable alert history
MONITOR_OFFSET_FILE = STATE_DIR / "monitor_offset.json"  # tail() bookmark

MONITOR_APP_LOG = LOG_DIR / "monitor_service.log"     # monitor's own operational log
GENERATOR_APP_LOG = LOG_DIR / "generator_service.log"  # generator's own operational log

# ---------------------------------------------------------------------------
# Log generator settings
# ---------------------------------------------------------------------------
GENERATOR_MIN_INTERVAL_SEC = 0.5   # fastest gap between simulated requests
GENERATOR_MAX_INTERVAL_SEC = 2.0   # slowest gap between simulated requests
GENERATOR_ERROR_RATE = 0.08        # probability a single request is a 4xx/5xx
GENERATOR_CRASH_RATE = 0.01        # probability of a full "server crash" burst

# ---------------------------------------------------------------------------
# Monitor settings
# ---------------------------------------------------------------------------
MONITOR_POLL_INTERVAL_SEC = 3      # how often the monitor re-reads the log tail
MONITOR_WINDOW_SEC = 30            # sliding window used to judge recent health
ERROR_THRESHOLD = 5                # >= this many 5xx in the window => WARNING
CRASH_THRESHOLD = 1                # >= this many crash markers => CRITICAL
HEARTBEAT_TIMEOUT_SEC = 20         # no new log lines for this long => suspicious
ALERT_COOLDOWN_SEC = 60            # minimum gap between repeat alerts of same kind

# ---------------------------------------------------------------------------
# Notification settings
# ---------------------------------------------------------------------------
# Email is optional. Leave SMTP_HOST empty to fall back to console + file
# alerts only (handy for a classroom / offline demo).
SMTP_HOST = ""                     # e.g. "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USERNAME = ""
SMTP_PASSWORD = ""
SMTP_USE_TLS = True
ALERT_FROM_ADDR = "monitor@example.com"
ALERT_TO_ADDRS = ["admin@example.com"]
