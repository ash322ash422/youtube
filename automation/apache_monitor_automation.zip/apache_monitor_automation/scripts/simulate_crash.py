"""
scripts/simulate_crash.py
==========================
Teaching helper: manually injects a crash burst (or a batch of plain 5xx
errors) directly into logs/access.log, so students can watch log_monitor.py
detect it and gui_status.py flip to RED on demand, instead of waiting for
log_generator.py to roll a random one.

Usage (run from the project root):
    python scripts/simulate_crash.py            # inject a full crash burst (CRITICAL)
    python scripts/simulate_crash.py --errors    # inject only 5xx errors (WARNING)
"""
import argparse
import sys
from pathlib import Path

# Allow running this script directly from the scripts/ folder.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config
from log_generator import crash_burst, error_line, write_log_line


def main() -> None:
    parser = argparse.ArgumentParser(description="Manually inject a test event into the access log.")
    parser.add_argument("--errors", action="store_true", help="inject 5xx errors only (WARNING level)")
    args = parser.parse_args()

    if args.errors:
        for _ in range(6):
            write_log_line(error_line())
        print(f"Injected 6 HTTP 5xx error lines into {config.ACCESS_LOG_FILE}")
    else:
        lines = crash_burst()
        for line in lines:
            write_log_line(line)
        print(f"Injected a CRASH burst ({len(lines)} lines) into {config.ACCESS_LOG_FILE}")


if __name__ == "__main__":
    main()
