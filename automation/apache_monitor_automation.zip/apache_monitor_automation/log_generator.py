"""
log_generator.py
=================
Simulates a live web server by continuously appending realistic Apache-style
log lines to logs/access.log. Most lines are normal 2xx/3xx traffic, but the
generator occasionally injects:

    * a run of HTTP 5xx errors (config.GENERATOR_ERROR_RATE), and
    * a full "server crash" burst (config.GENERATOR_CRASH_RATE) - several
      error responses followed by an Apache-error-log-style crash marker,
      then a pause to simulate the process restarting.

This gives log_monitor.py real signal to detect. Run this in its own
terminal/process:

    python log_generator.py

Stop with Ctrl+C (or SIGTERM).
"""
from __future__ import annotations

import logging
import random
import signal
import sys
import time
from datetime import datetime
from typing import List

import config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] generator: %(message)s",
    handlers=[
        logging.FileHandler(config.GENERATOR_APP_LOG, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("apache_monitor.generator")

IPS = [f"192.168.1.{i}" for i in range(2, 40)]
PATHS = ["/", "/index.html", "/api/users", "/api/orders", "/login",
         "/static/app.js", "/static/style.css", "/favicon.ico", "/checkout"]
METHODS = ["GET", "GET", "GET", "POST", "PUT", "DELETE"]
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "curl/8.4.0",
    "Mozilla/5.0 (X11; Linux x86_64)",
]
OK_STATUSES = [200, 200, 200, 201, 301, 304]
ERROR_STATUSES = [400, 401, 403, 404, 500, 502, 503, 504]

_running = True


def _apache_timestamp() -> str:
    return datetime.now().strftime("%d/%b/%Y:%H:%M:%S +0000")


def write_log_line(line: str) -> None:
    """Append a single line to the simulated access log. Public so other
    scripts (e.g. scripts/simulate_crash.py) can reuse it."""
    with config.ACCESS_LOG_FILE.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def normal_line() -> str:
    status = random.choice(OK_STATUSES)
    size = random.randint(200, 15000)
    return (f'{random.choice(IPS)} - - [{_apache_timestamp()}] '
            f'"{random.choice(METHODS)} {random.choice(PATHS)} HTTP/1.1" '
            f'{status} {size} "-" "{random.choice(USER_AGENTS)}"')


def error_line() -> str:
    status = random.choice(ERROR_STATUSES)
    size = random.randint(0, 500)
    return (f'{random.choice(IPS)} - - [{_apache_timestamp()}] '
            f'"{random.choice(METHODS)} {random.choice(PATHS)} HTTP/1.1" '
            f'{status} {size} "-" "{random.choice(USER_AGENTS)}"')


def crash_burst() -> List[str]:
    """Simulate a server crash: several 5xx responses plus an explicit
    Apache-error-log-style CRASH marker line that the monitor treats as
    critical."""
    lines = [error_line() for _ in range(random.randint(3, 6))]
    lines.append(
        f'[{datetime.now():%a %b %d %H:%M:%S %Y}] [core:error] [pid {random.randint(1000, 9999)}] '
        f'AH00052: Server crashed unexpectedly - CRASH - child process exited, restarting'
    )
    return lines


def _handle_shutdown(signum, frame):  # noqa: ARG001
    global _running
    logger.info("Shutdown signal received, stopping generator...")
    _running = False


def run() -> None:
    signal.signal(signal.SIGINT, _handle_shutdown)
    signal.signal(signal.SIGTERM, _handle_shutdown)
    logger.info("Log generator started -> writing to %s", config.ACCESS_LOG_FILE)

    while _running:
        roll = random.random()
        if roll < config.GENERATOR_CRASH_RATE:
            lines = crash_burst()
            for line in lines:
                write_log_line(line)
            logger.warning("Injected CRASH burst (%d lines)", len(lines))
            # simulate downtime: the "server" is restarting, no traffic for a bit
            time.sleep(random.uniform(5, 10))
        elif roll < config.GENERATOR_CRASH_RATE + config.GENERATOR_ERROR_RATE:
            write_log_line(error_line())
        else:
            write_log_line(normal_line())

        time.sleep(random.uniform(config.GENERATOR_MIN_INTERVAL_SEC,
                                   config.GENERATOR_MAX_INTERVAL_SEC))

    logger.info("Log generator stopped cleanly.")


if __name__ == "__main__":
    run()
